# OCPP Gateway

A secure WebSocket gateway for OCPP (Open Charge Point Protocol) built with NestJS and TypeScript.

## Features

- **Multi-version OCPP support** (1.6J, 2.0.1, 2.1)
- **Security validation** with suspicious pattern detection
- **Flood control** to prevent spam attacks
- **Redis integration** for session management
- **Kafka messaging** for event streaming
- **Connection management** with automatic cleanup

## Quick Start

```bash
# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Start development server
npm run start:dev

# Build for production
npm run build
npm start
```

## Environment Variables

```env
SERVICE_NAME=ocpp-gateway
PORT=3001
KAFKA_BROKERS=localhost:9092
REDIS_URL=redis://localhost:6379
FLOOD_LOG_COOLDOWN=300
WEBSOCKET_OCPP_PORT=8080
```

## WebSocket Endpoint

**Development**: `ws://localhost:3001/ocpp/{version}/{chargePointId}`
**Production**: `wss://your-domain.com/ocpp/{version}/{chargePointId}`

Example: `ws://localhost:3001/ocpp/1.6/CP-001`

Subprotocols are required and must match the version:
- `ocpp1.6` (alias: `ocpp1.6j`)
- `ocpp2.0.1`
- `ocpp2.1`

## Schema validation

- Uses official schemas for OCPP 1.6J/2.0.1/2.1.
- `additionalProperties` defaults to `false` for strict validation.
- Set `OCPP_SCHEMA_ALLOW_ADDITIONAL_ACTIONS` to allow extra fields for specific actions (default: `DataTransfer`).

## State machine strictness

- `OCPP_STATE_STRICT=true` enforces transaction/session consistency (unknown transactions return CallError).
- Set `OCPP_STATE_STRICT=false` to allow orphaned MeterValues/TransactionEvent updates during testing.

## Rate limits and payload size

- `OCPP_MAX_PAYLOAD_BYTES` rejects oversized frames (0 disables).
- `OCPP_PENDING_MESSAGE_LIMIT` caps queued frames before auth/session setup (0 disables).
- `OCPP_RATE_LIMIT_WINDOW_SECONDS` sets the counting window.
- `OCPP_RATE_LIMIT_PER_CP` and `OCPP_RATE_LIMIT_GLOBAL` apply to `MeterValues` and `StatusNotification`.

## Metrics

- `GET /metrics` returns JSON counters, gauges, rates, and optional alerts.
- `METRICS_RATE_WINDOW_SECONDS` controls the rolling rate window.
- Set `METRICS_ALERT_RATE_LIMITED_PER_SEC`, `METRICS_ALERT_AUTH_FAILURES_PER_SEC`,
  `METRICS_ALERT_ERROR_PER_SEC` to emit alert entries in `/metrics`.

## Command audit persistence

- Outbound CALLs are stored in Redis with their `uniqueId`, payload, and response payload/error.
- `COMMAND_AUDIT_TTL_SECONDS` controls how long audit entries are retained.
- `COMMAND_IDEMPOTENCY_TTL_SECONDS` controls how long `commandId` values are deduped
  (duplicates emit `CommandDuplicate` events).

## Resilience tuning

Kafka retry/circuit settings:
- `KAFKA_RETRY_MAX_RETRIES`, `KAFKA_RETRY_INITIAL_MS`, `KAFKA_RETRY_MAX_MS`, `KAFKA_RETRY_FACTOR`
- `KAFKA_CONNECTION_TIMEOUT_MS`, `KAFKA_REQUEST_TIMEOUT_MS`
- `KAFKA_CIRCUIT_FAILURE_THRESHOLD`, `KAFKA_CIRCUIT_OPEN_SECONDS`, `KAFKA_CIRCUIT_HALF_OPEN_SUCCESS`

Redis retry/circuit settings:
- `REDIS_RETRY_MAX_ATTEMPTS`, `REDIS_RETRY_INITIAL_DELAY_MS`, `REDIS_RETRY_MAX_DELAY_MS`
- `REDIS_CONNECT_TIMEOUT_MS`, `REDIS_MAX_RETRIES_PER_REQUEST`
- `REDIS_CIRCUIT_FAILURE_THRESHOLD`, `REDIS_CIRCUIT_OPEN_SECONDS`, `REDIS_CIRCUIT_HALF_OPEN_SUCCESS`

## Multi-node routing

- Each charge point session is claimed in Redis (`sessions:{chargePointId}`) with a `nodeId`.
- New connections are rejected if another node already owns the session.
- Commands are routed to the owning node via Kafka topic `cpms.command.requests.node.{nodeId}`.
- Stale sessions can be taken over if `SESSION_STALE_SECONDS` is exceeded; a force-disconnect is sent to the previous owner via `ocpp.session.control.node.{nodeId}`.

## Charger Identity & Auth

The gateway authenticates chargers against a Redis-backed identity record:

Key: `chargers:{chargePointId}`

```json
{
  "chargePointId": "CP-001",
  "stationId": "station-123",
  "tenantId": "tenant-abc",
  "status": "active",
  "allowedProtocols": ["1.6J", "2.0.1", "2.1"],
  "allowedIps": ["10.0.0.10"],
  "allowedCidrs": ["10.0.0.0/24"],
  "auth": {
    "type": "mtls",
    "allowedTypes": ["mtls"],
    "certificates": [
      {
        "fingerprint": "AA:BB:CC:DD:EE",
        "subject": "CN=CP-001",
        "validFrom": "2026-01-01T00:00:00Z",
        "validTo": "2027-01-01T00:00:00Z"
      }
    ]
  }
}
```

Auth modes:
- `basic`: `Authorization: Basic base64(username:password)`
- `token`: `Authorization: Bearer <token>` or `x-api-key: <token>`
- `mtls`: charger certificate subject/fingerprint must match the identity record

Secret hashing:
- `auth.hashAlgorithm` can be `sha256` or `scrypt` (defaults to `sha256` for backwards compatibility).
- Set `OCPP_AUTH_HASH_ALGORITHM=scrypt` to use scrypt for new hashes.
- Tune scrypt with `OCPP_AUTH_SCRYPT_N`, `OCPP_AUTH_SCRYPT_R`, `OCPP_AUTH_SCRYPT_P`, `OCPP_AUTH_SCRYPT_KEYLEN`.

IP allowlists:
- Global allowlist: `OCPP_ALLOWED_IPS`, `OCPP_ALLOWED_CIDRS`.
- Per-charger allowlist: `allowedIps`, `allowedCidrs` on the identity record.
- Set `OCPP_TRUST_PROXY=true` to honor `X-Forwarded-For` when behind a proxy.

Certificate rotation:
- Add multiple `certificates` entries with overlapping `validFrom`/`validTo` windows.

Revocation (denylist):
- Set `revoked-certs:{fingerprint}` in Redis (fingerprint normalized without `:`) to block a certificate immediately.
- You can also list `revokedFingerprints` on the identity record.
- `OCPP_REQUIRE_CERT_BINDING=true` enforces explicit `certificates` bindings for mTLS.

Provisioning audit:
- Use `npm run provision:charger <identity.json>` and `npm run revoke:cert <fingerprint>` to write identities and revocations.
- Each write emits an audit event to `cpms.audit.events` with actor metadata.
  - Set `PROVISION_ACTOR_ID`, `PROVISION_ACTOR_TYPE`, `PROVISION_ACTOR_IP`, `PROVISION_REASON`.
  - Optional provisioning helpers: `PROVISION_ALLOWED_PROTOCOLS`, `PROVISION_AUTH_TYPE`, `PROVISION_SECRET`,
    `PROVISION_SECRET_SALT`, `PROVISION_TOKEN`, `PROVISION_HASH_ALGORITHM`, `PROVISION_SCRYPT_N`,
    `PROVISION_SCRYPT_R`, `PROVISION_SCRYPT_P`, `PROVISION_SCRYPT_KEYLEN` (generates salted hashes when missing).

## TLS / mTLS settings

Configure TLS in `.env` to enable mTLS on the gateway:

```env
OCPP_TLS_ENABLED=true
OCPP_TLS_CLIENT_AUTH=true
OCPP_TLS_KEY_PATH=path/to/server.key
OCPP_TLS_CERT_PATH=path/to/server.crt
OCPP_TLS_CA_PATH=path/to/ca.pem
OCPP_TLS_CRL_PATH=path/to/crl.pem
OCPP_TLS_MIN_VERSION=TLSv1.2
OCPP_TLS_RELOAD_SECONDS=0
OCPP_TLS_CRL_RELOAD_SECONDS=0
```

If your PKI provides CRLs, set `OCPP_TLS_CRL_PATH` to enforce revocation at handshake.
Use `OCPP_TLS_RELOAD_SECONDS` (and/or `OCPP_TLS_CRL_RELOAD_SECONDS`) to reload rotated certs/CRLs without a restart.

## Security

- Validates charge point ID format (`CP-xxx`)
- Blocks suspicious paths (admin, login, etc.)
- Rate limiting with Redis-based flood control
- IP-based connection tracking

## Architecture

- **Gateway**: WebSocket connection handler
- **Service**: OCPP message processing
- **Adapters**: Version-specific protocol handlers
- **Guards**: Security validation layer
- **Managers**: Connection state management
